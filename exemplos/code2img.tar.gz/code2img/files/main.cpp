#include <iostream>
// Hello, World!
// clang++ main.cpp -o ola-mundo
int main( int argc, char** argv){
    std::cout << "Terminal Root, rules!" << '\n';
    return 0;
}
